from flask import Flask, request, jsonify, make_response
import numpy as np
import pandas as pd
import time
import psutil  # Para monitorar 
from scipy.ndimage import rotate
import matplotlib.pyplot as plt
import threading
import multiprocessing
import resource

app = Flask(__name__)


def algoritmo(H, g, tol=1e-4, max_iter=20):
    f = np.zeros((H.shape[1], 1))  
    r = g - H @ f
    p = H.T @ r

    for i in range(max_iter):
        alpha = (r.T @ r) / (p.T @ p)
        f += alpha * p
        r_new = r - alpha * (H @ p)
        if np.linalg.norm(r_new) < 1e-4:
            return f, i + 1  
        beta = (r_new.T @ r_new) / (r.T @ r)
        p = H.T @ r_new + beta * p
        r = r_new

    return f, max_iter


def gerar_imagem(dados, titulo="ABS", nome_arquivo="imagem.png"):
    dados_rotacionados = rotate(dados, angle=-90, reshape=True, mode='nearest')
    dados_rotacionados = np.fliplr(dados_rotacionados)
    plt.imshow(np.abs(dados_rotacionados), cmap='gray', interpolation='nearest')
    plt.title(titulo)
    plt.savefig(nome_arquivo)


@app.route('/reconstruir_imagem', methods=['POST'])
def reconstruir_imagem():
    data = request.json
    user = data['user']
    ganho = data['ganho']
    modelo = data['modelo']

    # Carregar os arquivos de H e g enviados
    H = np.array(data['H'])
    g = np.array(data['g'])

    # Execução do algoritmo de reconstrução
    start_time = time.time()
    resultado, iteracoes = algoritmo(H, g)
    end_time = time.time()

    # Gerar imagem e salvar
    heatmap_data = resultado.reshape(modelo['rows'], modelo['cols'])
    nome_arquivo = f"imagem_{user}_{int(end_time)}.png"
    # thread =  threading.Thread(gerar_imagem(heatmap_data, nome_arquivo=nome_arquivo))
    # thread = threading.Thread(target=gerar_imagem, args=(heatmap_data,), kwargs={'nome_arquivo': nome_arquivo})
    # thread.start()
    process = multiprocessing.Process(target=gerar_imagem, args=(heatmap_data,), kwargs={'nome_arquivo': nome_arquivo})
    process.start()

    # Informações adicionais
    tempo_execucao = end_time - start_time
    tamanho_imagem = heatmap_data.shape

    data = jsonify({
        'usuario': user,
        'iteracoes': iteracoes,
        'tempo_execucao': tempo_execucao,
        'tamanho_imagem': tamanho_imagem,
        'arquivo_imagem': nome_arquivo
    })
    return make_response(data, 200)




@app.route('/status_servidor', methods=['GET'])
def status_servidor():
    cpu_percent = psutil.cpu_percent(interval=1)
    memory_info = psutil.virtual_memory()

    return jsonify({
        'cpu_percent': cpu_percent,
        'memory_used': memory_info.used,
        'memory_total': memory_info.total
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
