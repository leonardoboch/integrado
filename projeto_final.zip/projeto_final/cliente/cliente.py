import requests
import numpy as np
import random
import time

# Função para simular o envio de dados ao servidor
def enviar_sinal():
    user = f"user_{random.randint(1, 100)}"
    ganho = random.uniform(0.5, 2.0)  # Ganho aleatório entre 0.5 e 2.0
    modelo = {'rows': 60, 'cols': 60}  # Modelo fixo 60x60
    
    # Gerando dados aleatórios para H e g
    H = np.random.rand(3600, 3600).tolist()  # Lista para ser enviada via JSON
    g = np.random.rand(3600, 1).tolist()

    dados = {
        'user': user,
        'ganho': ganho,
        'modelo': modelo,
        'H': H,
        'g': g
    }

    # Enviar dados para o servidor
    response = requests.post('http://localhost:5002/reconstruir_imagem', json=dados)
    print(response)
    if response.status_code == 200:
        resultado = response.json()
        print(resultado)
    else:
        print("Erro ao processar a imagem.")

# Função para monitorar o desempenho do servidor
def monitorar_desempenho():
    response = requests.get('http://localhost:5001/status_servidor')
    print(response)
    if response.status_code == 200:
        status = response.json()
        print(f"Uso de CPU: {status['cpu_percent']}%")
        print(f"Memória usada: {status['memory_used']} bytes")
        print(f"Memória total: {status['memory_total']} bytes")
    else:
        print("Erro ao obter status do servidor.")

# Simular o envio de sinais em intervalos de tempo aleatórios
for _ in range(5):  # Enviar 5 sinais
    enviar_sinal()
    monitorar_desempenho()
    time.sleep(random.randint(1, 5))  

