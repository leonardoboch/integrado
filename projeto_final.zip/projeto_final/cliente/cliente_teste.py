import requests
import numpy as np
import random
import time
import pandas as pd

# Função para simular o envio de dados ao servidor
def enviar_sinal(h, g, linha, coluna):
    user = f"user_{random.randint(1, 100)}"
    ganho = random.uniform(0.5, 2.0)  # Ganho aleatório entre 0.5 e 2.0s
    modelo = {'rows': linha, 'cols': coluna} 
    print(modelo)

    dados = {
        'user': user,
        'ganho': ganho,
        'modelo': modelo,
        'H': h,
        'g': g
    }
    response = requests.post('http://localhost:5002/reconstruir_imagem', json=dados)
    if response.status_code == 200:
        resultado = response.json()
        print(f"Imagem reconstruída com sucesso")
    else:
        print("Erro ao processar a imagem.")

def monitorar_desempenho():
    response = requests.get('http://localhost:5001/status_servidor')
    if response.status_code == 200:
        status = response.json()
        print(f"Uso de CPU: {status['cpu_percent']}%")
        print(f"Memória usada: {status['memory_used']} bytes")
        print(f"Memória total: {status['memory_total']} bytes")
    else:
        print("Erro ao obter status do servidor.")

# Simular o envio de sinais em intervalos de tempo aleatórios


def envia():
    random_number = 4
    print(random_number)
    H_1 = pd.read_csv("H-1.csv", header=None, delimiter=',').values.tolist() 
    G_1 = pd.read_csv("G-1.csv", header=None, delimiter=',').values.tolist() 
    G_2 = pd.read_csv("G-2.csv", header=None, delimiter=',').values.tolist() 
    G_3 = pd.read_csv("A-60x60-1.csv", header=None, delimiter=',').values.tolist() 
    H_2 = pd.read_csv("H-2.csv", header=None, delimiter=',').values.tolist() 
    g_1 = pd.read_csv("g-30x30-1.csv", header=None, delimiter=',').values.tolist() 
    g_2 = pd.read_csv("g-30x30-2.csv", header=None, delimiter=',').values.tolist() 
    g_3 = pd.read_csv("A-30x30-1.csv", header=None, delimiter=',').values.tolist() 
    
    if random_number == 1:
        enviar_sinal(H_1, G_1, 60, 60)
    elif random_number == 2:
        enviar_sinal(H_1, G_2, 60, 60)
    elif random_number == 3:
        enviar_sinal(H_1, G_3, 60, 60)
    elif random_number == 4:
        enviar_sinal(H_2, g_1, 30, 30)
    elif random_number == 5:
        enviar_sinal(H_2, g_2, 30, 30)
    elif random_number == 6:
        enviar_sinal(H_2, g_3, 30, 30)
envia()
monitorar_desempenho()
