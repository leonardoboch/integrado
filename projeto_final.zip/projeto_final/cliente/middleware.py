from flask import Flask, request, jsonify
import numpy as np
import time
from threading import Lock
from queue import Queue
import requests
import json

app = Flask(__name__)

# Fila de requisições e bloqueio para controle de execução
request_queue = Queue()
lock = Lock()

# Função para processar uma única requisição
def processar_requisicao(data):
    print("requisicao feita")
    response = requests.post('http://localhost:5001/reconstruir_imagem', json=data)
    timestamp = int(time.time())
    nome_arquivo = f'resposta_{timestamp}.json'
    
    with open(nome_arquivo, 'w') as arquivo_json:
        json.dump(response.json(), arquivo_json, indent=4)
    return response

# Middleware para gerenciar a fila de requisições
@app.before_request
def adicionar_fila():
    request_queue.put(request)

@app.after_request
def processar_fila(response):
    lock.acquire()  # Garante que apenas uma requisição está sendo processada por vez
    try:
        current_request = request_queue.get()
        if current_request:
            dados = current_request.get_json()
            resultado = processar_requisicao(dados)
            
            resultado_json = resultado.json()
            
            # Retorna a resposta com o conteúdo serializado
            resposta = jsonify(resultado_json)  

    finally:
        lock.release()  # libera requisicao
        request_queue.task_done() # marca task como feita

    return response  # Retorna o response original e não a nova resposta gerada


@app.route('/reconstruir_imagem', methods=['POST'])
def reconstruir_imagem():
    return jsonify({"message": "Sua requisição foi adicionada à fila, aguarde o processamento..."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
